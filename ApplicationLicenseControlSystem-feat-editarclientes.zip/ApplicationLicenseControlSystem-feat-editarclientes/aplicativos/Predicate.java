package aplicativos;
public class Predicate<T> {

  public boolean test(Aplicativo app) {return false;}

}
