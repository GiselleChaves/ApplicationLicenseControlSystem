package aplicativos;
public class Consumer<T> {

  public void accept(Aplicativo app) {}

}