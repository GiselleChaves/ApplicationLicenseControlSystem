import aplicativos.*;
import clientes.*;
import assinaturas.*;

public class Consumer<T> {

  public void accept(Aplicativo app) {}

}